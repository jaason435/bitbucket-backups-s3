# Bitbucket Backups
Take backups of your Bitbucket repositories on AWS S3.

Feel free to read about this with some more details on [Medium](https://medium.com/axons/essential-kubernetes-tools-94503209d1cb).

[![DockerHub Badge](https://dockeri.co/image/bouwe/bitbucket-backups-s3)](https://hub.docker.com/r/bouwe/bitbucket-backups-s3)

## Installation
Set the right environment variables in the secrets file.

```
kubectl apply -f kubernetes/
```

# Notes:
Run the following to update dependencies before uploading to Lambda
```pip3 install -t vendor -r aws_requirements.txt```